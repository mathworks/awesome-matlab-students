classdef ambassadorTests < matlab.unittest.TestCase

    methods (TestClassSetup)
        % Shared setup for the entire test class
    end

    methods (TestMethodSetup)
        % Setup for each test
    end

    methods (Test)
        % Test methods

        function playerByProfileId(testCase)
            % Search for players by organization.
            profileId = 140947;
            player = findPlayerByProfileId(profileId);
            % Validate the full name of the person with this ID: Ned Gulley
            % https://www.mathworks.com/matlabcentral/profile/authors/140947
            testCase.verifyTrue(player.nickname=="Ned Gulley");
        end

        function problemsByGroupTest(testCase)
            % Search for problems by the group ID.
            group_id = 122;
            problems = findProblemsByGroup(group_id);
            % Problem group 122 should have the following problems in it.
            correctList = [12 1946 44311 232 2024 44481 42340 752 8057];
            testCase.verifyTrue(isempty(setdiff([problems.id],correctList)))
        end

    end

end