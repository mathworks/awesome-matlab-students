function res = webreadThrottled(url, wo)
    % Need to throttle this at just less than the limit of 20
    % requests/minute.
    
    persistent numCalls timeWindowStart
    
    if isempty(numCalls)
        numCalls = 0;
    end
    if isempty(timeWindowStart)
        timeWindowStart = datetime("now");
    end

    numCalls = numCalls+1;
    currTime = datetime("now");

    if numCalls == 20
        timeToWait = 60 - seconds(currTime - timeWindowStart);
        if timeToWait > 0
            fprintf('Pausing for %4.1f seconds\n', timeToWait)
            pause(timeToWait)
        end
        numCalls = 1;
        timeWindowStart = datetime("now");
    end

    fprintf('%3d. %s\n', numCalls, url);
    res = webread(url,wo);
end