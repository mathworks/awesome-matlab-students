function players = findPlayerByProfileId(profileId, pageLimit)
    %findPlayerByProfileId Fetches player data based on their profile ID.
    %
    % Syntax:
    %   players = findPlayerByProfileId(profileId)
    %   players = findPlayerByProfileId(profileId, pageLimit)
    %
    % Description:
    %   This function retrieves player information from a web service, filtering
    %   by a specific profile ID. It supports pagination with a limit on the number
    %   of pages to fetch.
    %
    % Inputs:
    %   profileId - A numeric identifier for the player's profile. (Required)
    %   pageLimit - The maximum number of pages to retrieve. (Optional; default = 1)
    %
    % Outputs:
    %   players - A table containing player data fetched from the web service.
    %
    % Examples:
    %   players = findPlayerByProfileId(12345)
    %   players = findPlayerByProfileId(12345, 3)
    %
    % See also: webread, struct2table

    % Validate input arguments
    arguments
        profileId {mustBeNumeric}
        pageLimit {mustBeNumeric} = 1
    end

    % URL template for the web service request
    urlPart = "https://www.mathworks.com/matlabcentral/cody/players?page=%d&term=id%%3A%d";

    % Initialize web options for JSON content type
    wo = weboptions('ContentType', 'json', 'KeyName', 'Accept', 'KeyValue', 'application/json');

    % Initialize loop variables
    done = false;
    players = [];
    pageNum = 1;

    % Loop to fetch data page by page
    while ~done
        % Construct the URL for the current page
        url = sprintf(urlPart, pageNum, profileId);

        % Read data from the web service
        res = webreadThrottled(url, wo);

        % Check if the response is empty or the page limit is reached
        if isempty(fieldnames(res)) || pageNum > pageLimit
            done = true;
        else
            % Convert the response to a table and append to the players list
            p = struct2table(res);
            p.nickname = string(p.nickname);
            players = [players; p];
            pageNum = pageNum + 1;
        end
    end
end
