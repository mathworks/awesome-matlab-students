function players = findPlayersBySearch(searchTerm,pageLimit)
    %findPlayersBySearch
    %   players = findPlayersBySearch(searchTerm,pageLimit)

    arguments
        searchTerm 
        pageLimit {mustBeNumeric} = 1
    end

    urlPart = "https://www.mathworks.com/matlabcentral/cody/players?page=%d&term=%s";
    
    wo = weboptions('ContentType','json','KeyName','Accept','KeyValue','application/json');
    done = false;
    players = [];
    pageNum = 1;
    
    while ~done
        url = sprintf(urlPart,pageNum,searchTerm);
        res = webreadThrottled(url,wo);
        if isempty(fieldnames(res)) || pageNum > pageLimit
            done = true;
        else
            p = struct2table(res);
            p.nickname = string(p.nickname);
            players = [players; p];
            pageNum = pageNum + 1;
        end
    end
    
end