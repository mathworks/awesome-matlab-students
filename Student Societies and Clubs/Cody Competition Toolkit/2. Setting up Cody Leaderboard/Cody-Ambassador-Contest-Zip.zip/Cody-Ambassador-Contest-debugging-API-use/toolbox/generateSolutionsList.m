function allSolutions = generateSolutionsList(problems,players,contestStartDate,contestEndDate)
    
    solutionsList = {};
    
    for i = 1:height(problems)
        fprintf("Problem %d: %s\n",i, problems.title{i})
        solnsPerPage = 200;
        solutions = findSolutionsByProblem(problems.id(i),solnsPerPage,contestStartDate);
        
        % Keep only the solutions after the contest date
        keep = false(height(solutions),1);
        keep((solutions.created_at > contestStartDate) & (solutions.created_at < contestEndDate)) = true;
        solutions = solutions(keep,:);
        
        % Keep only the solutions from players on the list
        common = intersect(players.profile_id, solutions.profile_id);
        keep = false(height(solutions),1);
        for j = 1:length(common)
            keep(solutions.profile_id==common(j)) = true;
        end
        
        solutions = solutions(keep,:);
        p = table(problems.id(i)*ones(height(solutions),1));
        p.Properties.VariableNames = {'problem_id'};
        solutions = [p solutions];
        solutionsList{i} = solutions;
        
    end
    allSolutions = vertcat(solutionsList{:});
    
end