function solutions = findSolutionsByProblem(problem_id,solnsPerPage,startDate)
    %findSolutionsByProblem
    %   solutions = findSolutionsByProblem(problem_id)
    
    arguments
        problem_id {mustBeNumeric}
        solnsPerPage {mustBeNumeric} = 100
        startDate = datetime('now') - days(7)
    end
    
    urlpart1 = "https://www.mathworks.com/matlabcentral/cody/problems/";
    urlpart2 = "/solutions?per_page=" + solnsPerPage + "&page=";
    pageNum = 1;
    done = false;
    solutions = [];
    pageMax = 20;
    
    while ~done
        url = urlpart1 + problem_id + urlpart2 + pageNum;
        wo = weboptions( ...
            'ContentType','json', ...
            'KeyName','Accept', ...
            'KeyValue','application/json', ...
            'Timeout',10);
        res = webreadThrottled(url,wo);
        
        profile_id = zeros(size(res));
        nickname = strings(size(res));
        created_at = NaT(size(res));
        for i = 1:length(res)
            profile_id(i) = res(i).player.profile_id;
            nickname(i) = res(i).player.nickname;
            ds = res(i).created_at;
            ds = regexprep(ds,'T',' ');
            ds = regexprep(ds,'Z','');
            created_at(i) = datetime(ds,"Format","yyyy-MM-dd HH:mm:ss");
        end
        
        pageSolutions = table([res.solution_id]',created_at,[res.correct]',[res.size]', ...
            profile_id, nickname);
        pageSolutions.Properties.VariableNames = ...
            {'solution_id','created_at','correct','size','profile_id','nickname'};
        if pageSolutions.created_at(end)<startDate || pageNum > pageMax
            done = true;
            ix = pageSolutions.created_at<startDate;
            pageSolutions(ix,:) = [];
        else
            pageNum = pageNum + 1;
        end
        solutions = [solutions; pageSolutions];
        
    end
    
end
