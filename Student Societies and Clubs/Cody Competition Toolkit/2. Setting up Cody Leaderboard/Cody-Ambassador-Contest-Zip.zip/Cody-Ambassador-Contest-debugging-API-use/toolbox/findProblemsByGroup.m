function problems = findProblemsByGroup(group_id)
    % TODO: Replace this code with
    % InternalUseOnlyAPIsApi.get_problems_by_group_id(group_id)
    
    data = struct('group_id',group_id);
    url = 'https://www.mathworks.com/matlabcentral/cody/groups/problem_list';
    wo = weboptions('ContentType','json','KeyName','Accept','KeyValue','application/json');
    res = webwrite(url,data,wo);
    res = res.problem_list;
    problems = struct2table(res);
    problems.title = string(problems.title);
end