# The Cody Ambassador's Contest

This code supports a Cody contest run by student ambassadors.
It uses a number of public APIs that are documented here:

<https://communityapi.insidelabs.mathworks.com/>
