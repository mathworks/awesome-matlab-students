function playerScores = findScores(allSolutions)
idx = allSolutions.correct ==1;
correctSol = allSolutions(idx,:);

results = groupsummary(correctSol,{'full_name' 'problem_id'},'min','size');
results = groupsummary(results,'full_name','sum','min_size');
results.Properties.VariableNames{'GroupCount'} = 'num_solved';
results.Properties.VariableNames{'sum_min_size'} = 'total_size';

playerScores = sortrows(results,{'num_solved' 'total_size'},{'descend' 'ascend'});
end