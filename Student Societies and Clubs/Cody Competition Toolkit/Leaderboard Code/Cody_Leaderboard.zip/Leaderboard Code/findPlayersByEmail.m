function players = findPlayersByEmail(emailDomain,pageLimit)
    %findPlayersByEmail
    %   players = findPlayersByEmail(orgName)

    arguments
        emailDomain 
        pageLimit {mustBeNumeric} = 1
    end

    urlPart = "https://www.mathworks.com/matlabcentral/cody/players?page=%d&term=%s";
    
    wo = weboptions('ContentType','json','KeyName','Accept','KeyValue','application/json');
    done = false;
    players = [];
    pageNum = 1;
    
    while ~done
        url = sprintf(urlPart,pageNum,emailDomain);
        res = webread(url,wo);
        if isempty(fieldnames(res)) || pageNum > pageLimit
            done = true;
        else
            p = struct2table(res);
            p.full_name = string(p.full_name);
            players = [players; p];
            pageNum = pageNum + 1;
        end
    end
    
end