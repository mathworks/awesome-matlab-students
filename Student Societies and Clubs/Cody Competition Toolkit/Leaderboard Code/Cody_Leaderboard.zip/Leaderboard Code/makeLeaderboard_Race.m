function makeLeaderboard_Race(filename, allSolutions, gifOptions)
%Format dates
allSolutions.created_at = dateshift(allSolutions.created_at,'start','day');
allSolutions.created_at.Format = 'dd-MMMM-yyyy';

%Filter solutions to only correct solutions
idx = allSolutions.correct == 1;
correctSol = allSolutions(idx,:);
playersNameUnique = unique(correctSol.full_name);

%Pull dates in which there are solutions
compDays = unique(correctSol.created_at);

%Set number of participants to display
if height(playersNameUnique)>gifOptions.playerCap
    numPlayers = gifOptions.playerCap;
else
    numPlayers = height(playersNameUnique);
end

%Matrix for storing correct solutions by player
mat = zeros(numPlayers, numel(compDays));
scores = mat;

%Find earlieast date the each problem was solved by players
compSol = groupsummary(correctSol,{'full_name','problem_id'},'min',{'created_at','size'});

%Loop through players
for i = 1:numPlayers
    %Loop through each day of competition
    for j = 1:height(compDays)
        %Find all correct solutions by player i on day j
        tf = (compSol.full_name == playersNameUnique(i)) & (compSol.min_created_at == compDays(j));
        solForPlayeri = compSol{tf,2};
        mat(i,j) = numel(solForPlayeri);        
        scores(i,j) = sum(compSol{tf,5});
        
        %Add previous day numbers to current day
        if j >1
            mat(i,j) = mat(i,j) + mat(i,j-1);
            scores(i,j) = scores(i,j) + scores(i,j-1);
        end
    end
end

%Get rid of duplicate columns
i=2;
while 1
    if isequal(mat(:,i),mat(:,i-1))
        mat(:,i) = [];
        compDays(i) = [];
        i = 2;
    elseif i >= width(mat)
        break
    else
        i = i+1;
    end
end

Opt.outFileName=strcat(filename,'.gif');
Opt.xLabelStr='Number of Problems Solved';
Opt.yLabelStr='Player Name';
Opt.titleStr=strcat({'Rankings by Day | Date: '});
Opt.xTickLabelStrs=playersNameUnique;
Opt.days = compDays;
Opt.scores = scores;

barChartRace(mat,Opt, gifOptions)
end