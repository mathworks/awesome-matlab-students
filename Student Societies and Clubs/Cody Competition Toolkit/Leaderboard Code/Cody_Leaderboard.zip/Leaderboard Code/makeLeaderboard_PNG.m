function makeLeaderboard_PNG(filename, allSolutions, problems, schoolName, pngOptions)
    playerScore = findScores(allSolutions);
    a = zeros(height(playerScore),height(problems));

    if height(playerScore)>pngOptions.playerCap
        numPlayers = pngOptions.playerCap;
    else
        numPlayers = height(playerScore);
    end

    playerScore = sortrows(playerScore(1:numPlayers,:),{'num_solved' 'total_size'},{'ascend' 'descend'});
    playersNameUnique = playerScore.full_name(1:numPlayers);

    probStartPos = height(problems)/2;
    verticleSpace = 2.5;
    xMax = probStartPos+height(problems)*(1.125)+8;
    yMax = verticleSpace*(numPlayers+1.125)+numPlayers*.13;
    yMin = verticleSpace-1.5;

    figSize = [1024 576];
    fig = figure('Position',[300 100 figSize]);
    axes('Parent',fig,'Position',[0 0 1 1],'XColor','none','YColor','none');
    bg = imread(pngOptions.background);
    bg = imresize(bg,[figSize(2) figSize(1)]);
    imshow(bg)
    axes('XLim', [0 xMax],'YLim',[yMin yMax],'XColor','none','YColor','none',...
        'Position',[0.1 0.05 0.80 .8150],'Color',[0.902,0.902,0.902]);
    [t,s] = title(schoolName,'Cody Competition Leaderboard','Color',pngOptions.textColor,...
        'BackgroundColor',[0.902,0.902,0.902]);
    set(t,'FontSize',20);
    set(s,'Color',pngOptions.themeColor)
    
    hold on
    topPos = (yMax+(numPlayers+1)*verticleSpace-1.5)/2;
    text((probStartPos+height(problems)*(1.125))+2.5, topPos,{'Problems';'Solved'},'HorizontalAlignment','center','FontSize',8,'FontWeight','bold','Color',pngOptions.textColor);
    text(xMax-2, topPos,{'Total';'Score'},'HorizontalAlignment','center','FontSize',8,'FontWeight','bold','Color',pngOptions.textColor);

    for j = 1:height(problems)
        text(probStartPos+j*(1.125),topPos,num2str(j),'FontSize',8,'HorizontalAlignment','center','FontWeight','bold','Color',pngOptions.textColor)
        pnts_x = [probStartPos+j*(1.125)-.575 probStartPos+j*(1.125)-.575];
        pnts_y = [yMin yMax];
        plot(pnts_x,pnts_y,'Color',pngOptions.lineColor)
    end

    for i = 1:3
        pnts_x = [probStartPos+(height(problems)+1)*(1.125)-.575 probStartPos+(height(problems)+1)*(1.125)-.575;...
            (probStartPos+(height(problems)+1)*(1.125)-.575+xMax)/2 (probStartPos+(height(problems)+1)*(1.125)-.575+xMax)/2;...
            xMax xMax];
        pnts_y = [yMin yMax];
        plot(pnts_x(i,:),pnts_y, 'Color',pngOptions.lineColor)

        pnts_x = [0 0; 0 xMax; 0 xMax];
        pnts_y = [yMin yMax;
            yMax yMax;
            (numPlayers+1)*verticleSpace-1.5 (numPlayers+1)*verticleSpace-1.5];
        plot(pnts_x(i,:),pnts_y(i,:), 'Color', pngOptions.lineColor)
    end

    for i = 1:numPlayers
        for j = 1:height(problems)

            % Find any solutions for this player and problem where the answer is
            % correct
            tf = (strcmp(allSolutions.full_name, playersNameUnique(i))) & ...
                (allSolutions.correct == true) & ...
                (allSolutions.problem_id == problems.id(j));
            a(i,j) = any(tf);
        end
    end

    for i = 1:numPlayers
        text(1,i*verticleSpace, playersNameUnique(i), 'FontSize',8,'Color',pngOptions.textColor,'FontWeight','bold');
        pnts_x = [0,xMax];
        pnts_y = [i*verticleSpace-1.5 i*verticleSpace-1.5];
        plot(pnts_x,pnts_y, 'Color',pngOptions.lineColor)

        for j = 1:height(problems)
            if a(i,j)
                plot((probStartPos+j+j*.125),i*verticleSpace,'x','MarkerEdgeColor',pngOptions.themeColor)
            end
        end

        text((probStartPos+j*(1.125))+2.5,i*verticleSpace,num2str(sum(a(i,:))),'FontSize',8,'HorizontalAlignment','center','Color',pngOptions.themeColor);
        text(xMax-2,i*verticleSpace,num2str(playerScore.total_size((end-numPlayers)+i)),'FontSize',8,'HorizontalAlignment','center','Color',pngOptions.themeColor);
    end

    hold off
    saveas(fig,strcat(filename,'.png'));
end
