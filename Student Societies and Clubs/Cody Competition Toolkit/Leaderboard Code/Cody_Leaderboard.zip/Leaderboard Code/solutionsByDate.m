function makeLeaderboard_Race(filename, allSolutions, group_id, problems)

clear
load('allSolutions_MWjan-jul.mat');
allSolutions.created_at = dateshift(allSolutions.created_at,'start','day');
allSolutions.created_at.Format = 'dd-MMMM-yyyy';
compDays = unique(allSolutions.created_at);

playerCap = 10;
[playerScore] = findBestScores(allSolutions);
[playerScore,ix] = sortrows(playerScore,{'GroupCount','sum_size'},{'descend','ascend'});

playersNameUnique = sort(playerScore.full_name(1:20),'descend');

if height(playerScore)>playerCap
    numPlayers = playerCap;
else
    numPlayers = height(playerScore);
end

mat = zeros(numPlayers, height(compDays));

idx = allSolutions.correct == 1;
correctSol = allSolutions(idx,:);

for i = 1:numPlayers
    for j = 1:height(compDays)
        tf = (correctSol.full_name == playersNameUnique(i)) & (correctSol.created_at == compDays(j));
        solForPlayeri = correctSol{tf,1};
        mat(i,j) = numel(unique(solForPlayeri));
        if j >2
            mat(i,j) = mat(i,j) + mat(i,j-1);
        end
    end   
end

tmp = zeros(1,width(mat));
while 1
   
    if isequal(mat(:,i),mat(:,i-1))
        mat(:,i) = [];
        compDays(i) = []; 
        i = 2;
    elseif i == width(mat)
        break
    else
        i = i+1;
    end
    
end


% options
%Opt.xTickLabelStrs=cell(size(y,1),1);
Opt.outFileName='CodybyDay.gif';
Opt.xLabelStr='Number of Problems Solved';
Opt.yLabelStr='Player Name';
Opt.titleStr=strcat({'Top '},mat2str(numPlayers),{' Players | Date: '});
Opt.faceColor=[0,0,1];%'blue';
Opt.xTickLabelStrs=playersNameUnique;
Opt.days = compDays;


barChartRace(mat,Opt)