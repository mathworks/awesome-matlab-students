function players = findPlayersByOrganization(orgName)
    %findPlayersByOrganization
    %   players = findPlayersByOrganization(orgName)
    
    urlPart = "https://www.mathworks.com/matlabcentral/cody/players?term=organization%3A";
    doubleQuote = "%22";
    url = urlPart + doubleQuote + orgName + doubleQuote;
    wo = weboptions('ContentType','json','KeyName','Accept','KeyValue','application/json');
    res = webread(url,wo);
    players = struct2table(res);
    players.full_name = string(players.full_name);
    
end