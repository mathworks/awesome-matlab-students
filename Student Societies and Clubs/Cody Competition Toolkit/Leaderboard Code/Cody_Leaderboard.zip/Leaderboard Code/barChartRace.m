function barChartRace( inData, Opt, gifOptions)
%barChartRace wittern by Eiji Konaka, Jan/2020.
%
% Make bar chart race animation gif file from data (inData) with option (Opt).
% This file is tested and intended to work on R2016b (or later).
% inputs:
% inData(i,j); value of i-th index at j-th time instance
%   All values in this matrix are assumed to be positive,
%   and all values in the first column are assumed to be zero.
%   If it contains negative value, modify 'automatic scaling of horizontal
%   axis' line as you like.
%
% output:
% The output is directly written as an animation gif file with filename
% outFileName.
%
% Options:
%   xTickLabelStrs(i): vertical tick label of i-th index.
%   outFileName: output file name.
%   xLabelStr, yLabelStr, titleStr; Strings for horizoltal axis, vertical
%   axis, and title
%   faceColor: color in text (e.g., 'blue') or value (e.g., [])
% 

xTickLabelStrs=Opt.xTickLabelStrs;  % tick labels (vertical)

if isequal(Opt.outFileName(end-3:end),'.gif')
    outFileName=Opt.outFileName; % output gif name
else
    outFileName=[Opt.outFileName '.gif']; % output gif name
end


y=inData;
x=zeros(size(inData));
scores = Opt.scores;
x(:,1)=(1:size(inData,1))'; %starting position

for n1=2:size(inData,2)
    [~,ind]=sortrows([inData(:,n1) scores(:,n1)],[1 2],{'ascend' 'descend'});
    for n2=1:size(ind,1)
        x(ind(n2),n1)=n2;
    end
end

figure('Color',gifOptions.backgroundColor);

hold on

grid on;
set(gca,'FontName','Arial','FontSize',10)
h=barh(x(:,1),inData(:,1),'stacked','FaceAlpha',0.5, 'EdgeColor',gifOptions.highlightColor);
h.FaceColor=gifOptions.barColor;

xlim([0 max(max(h(1).YData)*1.2,1)])
ylim([0,size(inData,1)+1])
set(gca,'YTick',x(:,1),'YTickLabel',xTickLabelStrs(x(:,1)))
xlabel(Opt.xLabelStr,'Color',gifOptions.highlightColor)
ylabel(Opt.yLabelStr,'Color',gifOptions.highlightColor)

framesPerDataTick=24;
for k=2:size(y,2)
    
    
    for n1=0:framesPerDataTick
        tmp=((framesPerDataTick-n1)*x(:,k-1)+ (n1)*x(:,k))/framesPerDataTick;
        [val,ind]=sort(tmp);
        bWidth=min(diff(val));
        
        if bWidth>0.01
            h(1).XData= ((framesPerDataTick-n1)*x(:,k-1)+ (n1)*x(:,k))/framesPerDataTick;
            set(gca,'YTick',val,'YTickLabel',xTickLabelStrs(ind));
            
            
            h(1).YData=((framesPerDataTick-n1)*y(:,k-1)+ (n1)*y(:,k))/framesPerDataTick;
            set(h(1),'BarWidth',0.9/bWidth);
            % automatic scaling of horizontal axis
            xlim([0 max(max(h(1).YData)*1.2,1)])

            newTitle = strcat(Opt.titleStr, datestr(Opt.days(k),'dd mmm yyyy'));
            set(h.Parent.Title,'String',newTitle,'Color',gifOptions.highlightColor)
            
            
            refresh(1)
            
            
        end
        [A,map] = rgb2ind(frame2im( getframe(gcf)),256);
        
        if k==2 && n1==0
            imwrite(A,map,outFileName,'gif','DelayTime',0.5);
        else
            imwrite(A,map,outFileName,'gif','writemode', 'append','delaytime',1/framesPerDataTick);
        end
        
    end
    for n1=1:4  %stop between time instant
        imwrite(A,map,outFileName,'gif','writemode', 'append','delaytime',1/framesPerDataTick);
    end
end
%padding final frame to display longer.
    imwrite(A,map,outFileName,'gif','writemode', 'append','delaytime',0.5);
end

