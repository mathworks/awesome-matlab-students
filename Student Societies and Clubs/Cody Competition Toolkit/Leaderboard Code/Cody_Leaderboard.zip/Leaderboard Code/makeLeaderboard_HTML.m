function makeLeaderboard_HTML(filename, allSolutions, group_id, problems)
    idx = allSolutions.correct ==1;
    correctSol = allSolutions(idx,:);
    [playersNameUnique,ia] = unique(correctSol.full_name,'sorted');
    playersIdUnique = correctSol.profile_id(ia);
    a = zeros(length(playersIdUnique),height(problems));
    playerScore = findScores(allSolutions);

    for i = 1:length(playersIdUnique)
        for j = 1:height(problems)

            % Find any solutions for this player and problem where the answer is
            % correct
            tf = (allSolutions.profile_id == playersIdUnique(i)) & ...
                (allSolutions.correct == true) & ...
                (allSolutions.problem_id == problems.id(j));
            a(i,j) = any(tf);
        end
    end

    [~, ia] = sort(sum(a,2),'descend');
    a = a(ia,:);
    playersIdUnique = playersIdUnique(ia);
    playersNameUnique = playersNameUnique(ia);

    fid = fopen(strcat(filename,'.html'),'w');
    fprintf(fid,'<head>\n');
    fprintf(fid,'<title>Cody Contest Leaderboard</title>\n<meta charset="utf-8">\n');

    styleSheetStr = fileread('styles.css');
    fprintf(fid,'<style>%s</style>\n',styleSheetStr);
    fprintf(fid,'</head>\n');
    fprintf(fid,'<body>\n');
    linkStr = sprintf('https://www.mathworks.com/matlabcentral/cody/groups/%d',group_id);
    fprintf(fid,'<h1>Cody Ambassadors Contest</h1>');
    fprintf(fid,'<a href="%s">Group %d</a>\n',linkStr,group_id);
    fprintf(fid,'<table>');
    fprintf(fid,'<tr>');
    % Header
    fprintf(fid,'<th></th>');
    for j = 1:height(problems)
        linkStr = sprintf('https://www.mathworks.com/matlabcentral/cody/groups/%d/problems/%d', ...
            group_id, problems.id(j));
        fprintf(fid,'<th><a href="%s">%d</a></th>',linkStr,j);
    end
    fprintf(fid,'<th>Total</th>',j);
    fprintf(fid,'<th>Score</th>',j);

    fprintf(fid,'</tr>\n');
    fprintf(fid,'<tr>\n');
    for i = 1:length(playersIdUnique)
        linkStr = sprintf('https://www.mathworks.com/matlabcentral/profile/authors/%d',playersIdUnique(i));
        fprintf(fid,'<td><a href="%s">%s</a></td>',linkStr,playersNameUnique(i));
        for j = 1:height(problems)
            if a(i,j)
                linkStr = sprintf('https://www.mathworks.com/matlabcentral/cody/problems/%d/solutions?group_id=%d&term=player_id%%3A%d', ...
                    problems.id(j),group_id,playersIdUnique(i));
                fprintf(fid,'<td><a href="%s">x</a></td>',linkStr);
            else
                fprintf(fid,'<td></td>');
            end

        end
        fprintf(fid,'<td>%d</td>',sum(a(i,:)));
        fprintf(fid,'<td>%d</td>',playerScore.total_size(i));
        fprintf(fid,'</tr>\n');
    end
    fprintf(fid,'</table>');
    fprintf(fid,'</body>\n');
    fclose(fid);
end